using Microsoft.EntityFrameworkCore;
using Api.Models;

namespace Api.Data
{
    // Esta classe faz a ligação com o banco de dados
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {
        }

        public DbSet<Cliente> Clientes { get; set; } // Tabela de clientes
    }
}