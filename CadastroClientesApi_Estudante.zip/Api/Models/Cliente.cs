namespace Api.Models
{
    // Esta classe representa um cliente
    public class Cliente
    {
        public int Id { get; set; } // Identificador único
        public string Nome { get; set; } // Nome do cliente
        public string Email { get; set; } // Email do cliente
        public string Telefone { get; set; } // Telefone do cliente
    }
}