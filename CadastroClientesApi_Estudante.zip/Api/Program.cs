using Api.Data;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// Configurar o banco de dados SQLite
builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseSqlite("Data Source=clientes.db"));

// Adiciona suporte para controladores
builder.Services.AddControllers();

// Adiciona suporte para documentação com Swagger
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Habilita o Swagger
app.UseSwagger();
app.UseSwaggerUI();

// Usar autorização (mesmo que não configuramos nada ainda)
app.UseAuthorization();

// Mapeia os controladores
app.MapControllers();

app.Run();